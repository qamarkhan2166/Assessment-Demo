package com.example.mvvmdemoproject.data.model.games

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Reactions(var nope: Int) : Parcelable

  /*@SerializedName("1"  ) var 1  : Int? = null,
  @SerializedName("2"  ) var 2  : Int? = null,
  @SerializedName("3"  ) var 3  : Int? = null,
  @SerializedName("4"  ) var 4  : Int? = null,
  @SerializedName("5"  ) var 5  : Int? = null,
  @SerializedName("6"  ) var 6  : Int? = null,
  @SerializedName("7"  ) var 7  : Int? = null,
  @SerializedName("8"  ) var 8  : Int? = null,
  @SerializedName("9"  ) var 9  : Int? = null,
  @SerializedName("10" ) var 10 : Int? = null,
  @SerializedName("11" ) var 11 : Int? = null,
  @SerializedName("12" ) var 12 : Int? = null,
  @SerializedName("14" ) var 14 : Int? = null,
  @SerializedName("15" ) var 15 : Int? = null,
  @SerializedName("16" ) var 16 : Int? = null,
  @SerializedName("18" ) var 18 : Int? = null,
  @SerializedName("20" ) var 20 : Int? = null,
  @SerializedName("21" ) var 21 : Int? = null*/

// )
